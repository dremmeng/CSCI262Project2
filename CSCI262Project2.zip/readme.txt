Drew Remmenga
I struggled to overcome the problem of having more o's than x's and counting the wins for each side. The program got stuck multiple times and I needed assistance debugging. 
It was fun making the program spit out ever permutation but this wasn't very efficient. I disliked pruning the tree into the actually viable boards. 
three hours
